The PHP script files in this folder run automatically after installation.

The files should have the following naming convention:
<execution order>_<script name>_<enabled|disabled>.php

To disable a script, rename "enabled" to "disabled".
To change the order of a script, change the execution order number.