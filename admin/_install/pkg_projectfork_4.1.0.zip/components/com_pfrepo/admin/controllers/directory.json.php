<?php
/**
* @package      pkg_projectfork
* @subpackage   com_pfrepo
*
* @author       Tobias Kuhn (eaxs)
* @copyright    Copyright (C) 2006-2013 Tobias Kuhn. All rights reserved.
* @license      http://www.gnu.org/licenses/gpl.html GNU/GPL, see LICENSE.txt
**/

defined('_JEXEC') or die();


jimport('projectfork.controller.form.json');


/**
 * Projectfork Directory Form Controller
 *
 */
class PFrepoControllerDirectory extends PFControllerFormJson
{

}
