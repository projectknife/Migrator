<?php
/**
 * @package      Projectfork Pro
 * @subpackage   Designs
 *
 * @author       Tobias Kuhn (eaxs)
 * @copyright    Copyright (C) 2006-2012 Tobias Kuhn. All rights reserved.
 * @license      http://www.gnu.org/licenses/gpl.html GNU/GPL, see LICENSE.txt
 */

defined('_JEXEC') or die();


return JError::raiseWarning(404, JText::_('COM_PFDESIGNS_PLACEHOLDER'));
