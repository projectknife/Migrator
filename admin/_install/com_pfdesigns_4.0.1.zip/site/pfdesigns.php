<?php
/**
 * @package      Projectfork Pro
 * @subpackage   Designs
 *
 * @author       Tobias Kuhn (eaxs)
 * @copyright    Copyright (C) 2006-2013 Tobias Kuhn. All rights reserved.
 * @license      http://www.gnu.org/licenses/gpl.html GNU/GPL, see LICENSE.txt
 */

defined('_JEXEC') or die();


$lang = JFactory::getLanguage();
$lang->load('com_pfdesigns', JPATH_ADMINISTRATOR);

return JError::raiseWarning(404, JText::_('COM_PFDESIGNS_PLACEHOLDER'));
